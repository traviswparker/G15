make maintainer-clean; rm -rf autom4te.cache/ configure *.in aclocal.m4 *~ config
