#/bin/bash
autoreconf --install && ./configure && make && sudo make install || exit 1
